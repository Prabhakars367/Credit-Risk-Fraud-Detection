# Credit Risk & Fraud Detection App

Streamlit app for predicting fraud using a trained ML model.