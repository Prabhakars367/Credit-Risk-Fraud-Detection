import streamlit as st
import pandas as pd
import joblib

model = joblib.load("model.pkl")

st.title("💳 Credit Card Fraud Detector")

uploaded_file = st.file_uploader("Upload transaction CSV", type="csv")
if uploaded_file:
    input_df = pd.read_csv(uploaded_file)
    st.write("Uploaded data preview:", input_df.head())

    if st.button("Predict"):
        input_df = input_df.drop(columns=['Time'], errors='ignore')
        preds = model.predict(input_df)
        input_df["Prediction"] = preds
        st.write(input_df)
        st.success("Prediction completed ✅")
